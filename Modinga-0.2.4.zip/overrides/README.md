# Modinga

Just download the ***.zip** file frome the [releases tab](https://github.com/sephiroth1993/Modinga-FORGE-MC-1-19-2/releases/latest), and drop it to "[Prism Launcher](https://prismlauncher.org)" or import it with "[GDLauncher](https://gdlauncher.com)"
